--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.11
-- Dumped by pg_dump version 9.6.11

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE ONLY public."Vote" DROP CONSTRAINT "Vote_student_id_fkey";
ALTER TABLE ONLY public."Vote" DROP CONSTRAINT "Vote_course_id_fkey";
ALTER TABLE ONLY public."Exam" DROP CONSTRAINT "Exam_course_id_fkey";
ALTER TABLE ONLY public."ExamResult" DROP CONSTRAINT "ExamResult_student_id_fkey";
ALTER TABLE ONLY public."ExamResult" DROP CONSTRAINT "ExamResult_exam_id_fkey";
ALTER TABLE ONLY public."Enrolled" DROP CONSTRAINT "Enrolled_student_id_fkey";
ALTER TABLE ONLY public."Enrolled" DROP CONSTRAINT "Enrolled_course_id_fkey";
ALTER TABLE ONLY public."CourseDescription" DROP CONSTRAINT "CourseDescription_course_id_fkey";
ALTER TABLE ONLY public."CourseCategory" DROP CONSTRAINT "CourseCategory_course_id_fkey";
ALTER TABLE ONLY public."CourseCategory" DROP CONSTRAINT "CourseCategory_category_id_fkey";
ALTER TABLE ONLY public."CourseArchievement" DROP CONSTRAINT "CourseArchivement_course_id_fkey";
ALTER TABLE ONLY public."ClickRecord" DROP CONSTRAINT "ClickRecord_student_id_fkey";
ALTER TABLE ONLY public."ClickRecord" DROP CONSTRAINT "ClickRecord_category_id_fkey";
ALTER TABLE ONLY public."AssignTeacher" DROP CONSTRAINT "AssignTeacher_teacher_id_fkey";
ALTER TABLE ONLY public."AssignTeacher" DROP CONSTRAINT "AssignTeacher_course_id_fkey";
ALTER TABLE public."Vote" DROP CONSTRAINT vote_check;
ALTER TABLE ONLY public."Vote" DROP CONSTRAINT "Vote_pkey";
ALTER TABLE ONLY public."Teacher" DROP CONSTRAINT "Teacher_pkey";
ALTER TABLE ONLY public."Teacher" DROP CONSTRAINT "Teacher_email_key";
ALTER TABLE ONLY public."Student" DROP CONSTRAINT "Student_pkey";
ALTER TABLE ONLY public."Exam" DROP CONSTRAINT "Exam_pkey";
ALTER TABLE ONLY public."Course" DROP CONSTRAINT "Course_pkey";
ALTER TABLE ONLY public."ClickRecord" DROP CONSTRAINT "ClickRecord_pkey";
ALTER TABLE ONLY public."Category" DROP CONSTRAINT "Category_pkey";
ALTER TABLE ONLY public."AssignTeacher" DROP CONSTRAINT "AssignTeacher_pkey";
ALTER TABLE ONLY public."Admin" DROP CONSTRAINT "Admin_pkey";
ALTER TABLE public."Student" ALTER COLUMN student_id DROP DEFAULT;
ALTER TABLE public."Course" ALTER COLUMN course_id DROP DEFAULT;
ALTER TABLE public."Category" ALTER COLUMN category_id DROP DEFAULT;
DROP SEQUENCE public.student_studentid_seq;
DROP TABLE public."Vote";
DROP TABLE public."Teacher";
DROP TABLE public."Student";
DROP TABLE public."ExamResult";
DROP TABLE public."Exam";
DROP TABLE public."Enrolled";
DROP SEQUENCE public."Course_course_id_seq";
DROP TABLE public."CourseRequirement";
DROP TABLE public."CourseDescription";
DROP TABLE public."CourseCategory";
DROP TABLE public."CourseArchievement";
DROP TABLE public."Course";
DROP TABLE public."ClickRecord";
DROP SEQUENCE public."Category_category_id_seq";
DROP TABLE public."Category";
DROP TABLE public."AssignTeacher";
DROP TABLE public."Admin";
DROP EXTENSION adminpack;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: DATABASE postgres; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON DATABASE postgres IS 'default administrative connection database';


--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: Admin; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Admin" (
    admin_id integer NOT NULL,
    name character varying(50),
    email character varying,
    password character varying,
    address character varying,
    level character(2),
    create_at timestamp without time zone
);


ALTER TABLE public."Admin" OWNER TO postgres;

--
-- Name: AssignTeacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."AssignTeacher" (
    teacher_id integer NOT NULL,
    course_id integer NOT NULL,
    assigned_date timestamp without time zone
);


ALTER TABLE public."AssignTeacher" OWNER TO postgres;

--
-- Name: Category; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Category" (
    category_id integer NOT NULL,
    category character varying NOT NULL
);


ALTER TABLE public."Category" OWNER TO postgres;

--
-- Name: Category_category_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Category_category_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Category_category_id_seq" OWNER TO postgres;

--
-- Name: Category_category_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Category_category_id_seq" OWNED BY public."Category".category_id;


--
-- Name: ClickRecord; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ClickRecord" (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    click integer
);


ALTER TABLE public."ClickRecord" OWNER TO postgres;

--
-- Name: Course; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Course" (
    course_id integer NOT NULL,
    name character varying,
    price integer,
    created_at timestamp without time zone,
    cover character varying,
    avatar character varying,
    discount integer DEFAULT 0
);


ALTER TABLE public."Course" OWNER TO postgres;

--
-- Name: CourseArchievement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseArchievement" (
    course_id integer,
    description character varying
);


ALTER TABLE public."CourseArchievement" OWNER TO postgres;

--
-- Name: CourseCategory; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseCategory" (
    course_id integer,
    category_id integer
);


ALTER TABLE public."CourseCategory" OWNER TO postgres;

--
-- Name: CourseDescription; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseDescription" (
    course_id integer,
    description character varying
);


ALTER TABLE public."CourseDescription" OWNER TO postgres;

--
-- Name: CourseRequirement; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."CourseRequirement" (
    course_id integer,
    description character varying(300)
);


ALTER TABLE public."CourseRequirement" OWNER TO postgres;

--
-- Name: Course_course_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Course_course_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Course_course_id_seq" OWNER TO postgres;

--
-- Name: Course_course_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Course_course_id_seq" OWNED BY public."Course".course_id;


--
-- Name: Enrolled; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Enrolled" (
    student_id integer,
    course_id integer,
    enrolled_date timestamp without time zone
);


ALTER TABLE public."Enrolled" OWNER TO postgres;

--
-- Name: Exam; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Exam" (
    exam_id integer NOT NULL,
    course_id integer,
    duration integer
);


ALTER TABLE public."Exam" OWNER TO postgres;

--
-- Name: ExamResult; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."ExamResult" (
    student_id integer,
    exam_id integer,
    mark double precision,
    CONSTRAINT "ExamResult_mark_check" CHECK (((mark > (0)::double precision) AND (mark < (10)::double precision)))
);


ALTER TABLE public."ExamResult" OWNER TO postgres;

--
-- Name: Student; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Student" (
    student_id bigint NOT NULL,
    name character varying,
    email character varying,
    password character varying,
    address character varying,
    date_of_birth date,
    create_at timestamp without time zone,
    buget integer DEFAULT 0
);


ALTER TABLE public."Student" OWNER TO postgres;

--
-- Name: Teacher; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Teacher" (
    teacher_id integer NOT NULL,
    name character varying,
    phone character varying,
    email character varying,
    password character varying,
    address character varying,
    certificate character varying,
    created_at timestamp without time zone,
    picture character varying
);


ALTER TABLE public."Teacher" OWNER TO postgres;

--
-- Name: Vote; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Vote" (
    student_id integer NOT NULL,
    course_id integer NOT NULL,
    rate integer
);


ALTER TABLE public."Vote" OWNER TO postgres;

--
-- Name: student_studentid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.student_studentid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.student_studentid_seq OWNER TO postgres;

--
-- Name: student_studentid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.student_studentid_seq OWNED BY public."Student".student_id;


--
-- Name: Category category_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category" ALTER COLUMN category_id SET DEFAULT nextval('public."Category_category_id_seq"'::regclass);


--
-- Name: Course course_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course" ALTER COLUMN course_id SET DEFAULT nextval('public."Course_course_id_seq"'::regclass);


--
-- Name: Student student_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Student" ALTER COLUMN student_id SET DEFAULT nextval('public.student_studentid_seq'::regclass);


--
-- Data for Name: Admin; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Admin" (admin_id, name, email, password, address, level, create_at) FROM stdin;
\.
COPY public."Admin" (admin_id, name, email, password, address, level, create_at) FROM '$$PATH$$/2228.dat';

--
-- Data for Name: AssignTeacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."AssignTeacher" (teacher_id, course_id, assigned_date) FROM stdin;
\.
COPY public."AssignTeacher" (teacher_id, course_id, assigned_date) FROM '$$PATH$$/2229.dat';

--
-- Data for Name: Category; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Category" (category_id, category) FROM stdin;
\.
COPY public."Category" (category_id, category) FROM '$$PATH$$/2230.dat';

--
-- Name: Category_category_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Category_category_id_seq"', 6, true);


--
-- Data for Name: ClickRecord; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ClickRecord" (student_id, course_id, click) FROM stdin;
\.
COPY public."ClickRecord" (student_id, course_id, click) FROM '$$PATH$$/2231.dat';

--
-- Data for Name: Course; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Course" (course_id, name, price, created_at, cover, avatar, discount) FROM stdin;
\.
COPY public."Course" (course_id, name, price, created_at, cover, avatar, discount) FROM '$$PATH$$/2232.dat';

--
-- Data for Name: CourseArchievement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseArchievement" (course_id, description) FROM stdin;
\.
COPY public."CourseArchievement" (course_id, description) FROM '$$PATH$$/2233.dat';

--
-- Data for Name: CourseCategory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseCategory" (course_id, category_id) FROM stdin;
\.
COPY public."CourseCategory" (course_id, category_id) FROM '$$PATH$$/2234.dat';

--
-- Data for Name: CourseDescription; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseDescription" (course_id, description) FROM stdin;
\.
COPY public."CourseDescription" (course_id, description) FROM '$$PATH$$/2235.dat';

--
-- Data for Name: CourseRequirement; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."CourseRequirement" (course_id, description) FROM stdin;
\.
COPY public."CourseRequirement" (course_id, description) FROM '$$PATH$$/2242.dat';

--
-- Name: Course_course_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Course_course_id_seq"', 6, true);


--
-- Data for Name: Enrolled; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Enrolled" (student_id, course_id, enrolled_date) FROM stdin;
\.
COPY public."Enrolled" (student_id, course_id, enrolled_date) FROM '$$PATH$$/2236.dat';

--
-- Data for Name: Exam; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Exam" (exam_id, course_id, duration) FROM stdin;
\.
COPY public."Exam" (exam_id, course_id, duration) FROM '$$PATH$$/2237.dat';

--
-- Data for Name: ExamResult; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."ExamResult" (student_id, exam_id, mark) FROM stdin;
\.
COPY public."ExamResult" (student_id, exam_id, mark) FROM '$$PATH$$/2238.dat';

--
-- Data for Name: Student; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Student" (student_id, name, email, password, address, date_of_birth, create_at, buget) FROM stdin;
\.
COPY public."Student" (student_id, name, email, password, address, date_of_birth, create_at, buget) FROM '$$PATH$$/2239.dat';

--
-- Data for Name: Teacher; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Teacher" (teacher_id, name, phone, email, password, address, certificate, created_at, picture) FROM stdin;
\.
COPY public."Teacher" (teacher_id, name, phone, email, password, address, certificate, created_at, picture) FROM '$$PATH$$/2240.dat';

--
-- Data for Name: Vote; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Vote" (student_id, course_id, rate) FROM stdin;
\.
COPY public."Vote" (student_id, course_id, rate) FROM '$$PATH$$/2241.dat';

--
-- Name: student_studentid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.student_studentid_seq', 22, true);


--
-- Name: Admin Admin_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Admin"
    ADD CONSTRAINT "Admin_pkey" PRIMARY KEY (admin_id);


--
-- Name: AssignTeacher AssignTeacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignTeacher"
    ADD CONSTRAINT "AssignTeacher_pkey" PRIMARY KEY (teacher_id, course_id);


--
-- Name: Category Category_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Category"
    ADD CONSTRAINT "Category_pkey" PRIMARY KEY (category_id);


--
-- Name: ClickRecord ClickRecord_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClickRecord"
    ADD CONSTRAINT "ClickRecord_pkey" PRIMARY KEY (student_id, course_id);


--
-- Name: Course Course_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Course"
    ADD CONSTRAINT "Course_pkey" PRIMARY KEY (course_id);


--
-- Name: Exam Exam_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Exam"
    ADD CONSTRAINT "Exam_pkey" PRIMARY KEY (exam_id);


--
-- Name: Student Student_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Student"
    ADD CONSTRAINT "Student_pkey" PRIMARY KEY (student_id);


--
-- Name: Teacher Teacher_email_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teacher"
    ADD CONSTRAINT "Teacher_email_key" UNIQUE (email);


--
-- Name: Teacher Teacher_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Teacher"
    ADD CONSTRAINT "Teacher_pkey" PRIMARY KEY (teacher_id);


--
-- Name: Vote Vote_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_pkey" PRIMARY KEY (student_id, course_id);


--
-- Name: Vote vote_check; Type: CHECK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE public."Vote"
    ADD CONSTRAINT vote_check CHECK (((rate >= 0) AND (rate <= 5))) NOT VALID;


--
-- Name: AssignTeacher AssignTeacher_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignTeacher"
    ADD CONSTRAINT "AssignTeacher_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: AssignTeacher AssignTeacher_teacher_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."AssignTeacher"
    ADD CONSTRAINT "AssignTeacher_teacher_id_fkey" FOREIGN KEY (teacher_id) REFERENCES public."Teacher"(teacher_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ClickRecord ClickRecord_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClickRecord"
    ADD CONSTRAINT "ClickRecord_category_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id);


--
-- Name: ClickRecord ClickRecord_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ClickRecord"
    ADD CONSTRAINT "ClickRecord_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."Student"(student_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseArchievement CourseArchivement_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseArchievement"
    ADD CONSTRAINT "CourseArchivement_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseCategory CourseCategory_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseCategory"
    ADD CONSTRAINT "CourseCategory_category_id_fkey" FOREIGN KEY (category_id) REFERENCES public."Category"(category_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseCategory CourseCategory_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseCategory"
    ADD CONSTRAINT "CourseCategory_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: CourseDescription CourseDescription_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."CourseDescription"
    ADD CONSTRAINT "CourseDescription_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Enrolled Enrolled_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrolled"
    ADD CONSTRAINT "Enrolled_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Enrolled Enrolled_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Enrolled"
    ADD CONSTRAINT "Enrolled_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."Student"(student_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExamResult ExamResult_exam_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamResult"
    ADD CONSTRAINT "ExamResult_exam_id_fkey" FOREIGN KEY (exam_id) REFERENCES public."Exam"(exam_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: ExamResult ExamResult_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."ExamResult"
    ADD CONSTRAINT "ExamResult_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."Student"(student_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Exam Exam_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Exam"
    ADD CONSTRAINT "Exam_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_course_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_course_id_fkey" FOREIGN KEY (course_id) REFERENCES public."Course"(course_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Vote Vote_student_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Vote"
    ADD CONSTRAINT "Vote_student_id_fkey" FOREIGN KEY (student_id) REFERENCES public."Student"(student_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

